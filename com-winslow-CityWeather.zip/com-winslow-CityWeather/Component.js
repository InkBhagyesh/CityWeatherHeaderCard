sap.ui.define(['sap/ui/core/UIComponent'],
	function(UIComponent) {
	"use strict";

	var Component = UIComponent.extend("com.winslow.CityWeather.Component", {

		metadata : {
			manifest: "json"
		}
	});

	return Component;

});
